﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Drivers.Model
{
    public class Trip
    {
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public float Miles { get; set; }
        public double SpeedMph { get; set; }
    }
}
