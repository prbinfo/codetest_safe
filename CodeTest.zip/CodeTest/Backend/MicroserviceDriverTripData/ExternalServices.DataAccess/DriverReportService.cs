﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Drivers.Model;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;

namespace ExternalServices.DataAccess
{
    public class DriverReportService : IDriverReportService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;
        public DriverReportService(IConfiguration configuration, ILogger<DriverReportService> logger)
        {
            this._configuration = configuration;
            this._logger = logger;
        }
        public IEnumerable<DriverReport> GetDriverReports()
        {
            var drvrList = ReadTripData();
            List<DriverReport> drvrReports = new List<DriverReport>();

            try
            {
                var uniqueDrivers = drvrList.Distinct().Select(s => s.Name);
                foreach (var drvr in uniqueDrivers)
                {
                    var trips = drvrList.FirstOrDefault(d => d.Name == drvr).Trips;
                    var totalMiles = Math.Round(trips.Sum(d => d.Miles));
                    if (totalMiles > 0)
                    {
                        var avgSpeed = Math.Round(trips.Average(r => r.SpeedMph));
                        if (avgSpeed > 5 && avgSpeed <= 100)
                        {
                            drvrReports.Add(new DriverReport() { Name = drvr, TotalMiles = Convert.ToInt32(totalMiles), AverageSpeed = Convert.ToInt32(avgSpeed) });
                        }
                    }
                }
            }
            catch (Exception)
            {

                _logger.LogInformation("Log message in GetDriverReports method");
            }

            return drvrReports.OrderBy(d => d.TotalMiles);
        }
        private double getDrivingDuration(TimeSpan start, TimeSpan end)
        {
            int secInAMinute = 60;
            int minsInHour = 60;
            double durationInSecs = end.TotalSeconds - start.TotalSeconds;
            double durationInMins = durationInSecs / secInAMinute;

            return durationInMins / minsInHour;
        }

        private IEnumerable<Driver> ReadTripData()
        {
            List<Driver> drvrList = new List<Driver>();
            try
            {
                string dataPath = _configuration.GetValue<string>("DataFile");
                string[] lines = System.IO.File.ReadAllLines(string.Format("Data\\{0}", dataPath));
                foreach (var line in lines)
                {
                    string[] lineArray = line.Split(" ");
                    if (line.StartsWith("Driver"))
                    {
                        drvrList.Add(new Driver() { Name = lineArray[1], Trips = new List<Trip>() }); ;
                    }
                    else if (line.StartsWith("Trip"))
                    {
                        var drvObj = drvrList.FirstOrDefault(d => d.Name == lineArray[1]);
                        if (drvObj != null)
                        {
                            drvObj.Trips.Add(new Trip()
                            {
                                StartTime = TimeSpan.Parse(lineArray[2]),
                                EndTime = TimeSpan.Parse(lineArray[3]),
                                Miles = float.Parse(lineArray[4]),
                                SpeedMph = float.Parse(lineArray[4]) / getDrivingDuration(TimeSpan.Parse(lineArray[2]), TimeSpan.Parse(lineArray[3]))
                            });
                        }
                    }
                }
            }
            catch (Exception)
            {

                _logger.LogInformation("Log message in ReadTripData method");
            }
            return drvrList;

        }

        public bool FileUpload(string inputFile)
        {
            bool isUploadSuccess = false;

            if (File.Exists(inputFile))
            {
                try
                {
                    string dataPath = _configuration.GetValue<string>("DataFile");
                    string[] lines = System.IO.File.ReadAllLines(inputFile);
                    System.IO.File.WriteAllLines(string.Format("Data\\{0}", dataPath), lines);
                    isUploadSuccess = true;
                }
                catch (Exception)
                {

                    _logger.LogInformation("Log message in FileUpload method");
                }
            }
            return isUploadSuccess;
        }
    }
}
