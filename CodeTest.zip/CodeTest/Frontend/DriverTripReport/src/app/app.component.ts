import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http'
import { DriverServiceService } from './services/driver-service.service';

@Component({
  selector: 'pm-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'My Angular Project!';
  formdata: any;
  fileToUpload: any;
  reportData: any;
  constructor(private driverServiceService: DriverServiceService) {
  }
  ngOnInit() {
    this.formdata = new FormGroup({
      fileName: new FormControl(""),
    });
  }
  onSubmit(data) {    
    this.driverServiceService.invokeFileUploadPost(data.fileName).subscribe(result => console.log(result))
    this.driverServiceService.getReport().subscribe(data => {  
      this.reportData = data
    });
  }  
}
