﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Microsoft.AspNetCore.Http;

namespace UploadFileService.Controllers
{
    [ApiController]
    [Route("[Controller]")]
    public class UploadController : Controller
    {
        [HttpPost]
        public async Task<bool> UploadFile(IFormFile inputFile)
        {
            return await FileUpload(inputFile);
        }

        private static async Task<bool> FileUpload(IFormFile inputFile)
        {
            string path = "";
            bool isUploadSuccess = false;
            try
            {
                if (inputFile.Length > 0)
                {
                    string fileName = Guid.NewGuid() + Path.GetExtension(inputFile.FileName);
                    path = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "Data"));
                    using (FileStream fileStream = new FileStream(Path.Combine(path, fileName), FileMode.Create))
                    {
                        await inputFile.CopyToAsync(fileStream);
                    }
                    isUploadSuccess = true;
                }
                else
                {
                    isUploadSuccess = false;
                }
            }
            catch (Exception)
            {

                throw;
            }

            return isUploadSuccess;
        }
    }
}
