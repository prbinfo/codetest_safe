using Drivers.Model;
using ExternalServices.DataAccess;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using TripService;
using TripService.Controllers;

namespace TripService.Test
{
    [TestClass]
    public class TripControllerTest
    {
        private TripController controller;
        private DriverReport _driverReport;

        [TestInitialize]
        public void SetUp()
        {
            Mock<IConfigurationSection> mockSection = new Mock<IConfigurationSection>();
            mockSection.Setup(x => x.Value).Returns("input.txt");

            Mock<IConfiguration> mockConfig = new Mock<IConfiguration>();
            mockConfig.Setup(x => x.GetSection(It.Is<string>(k => k == "DataFile"))).Returns(mockSection.Object);
            Mock<IDriverReportService> mockDrvr = new Mock<IDriverReportService>();
            var mock = new Mock<ILogger<TripController>>();
            ILogger<TripController> logger = mock.Object;
            controller = new TripController(mockDrvr.Object, logger);
            this._driverReport = new DriverReport();

        }
        [TestMethod]
        public void WhenRequestCallGet_ReturnsOKResponse()        
        {
            IEnumerable<DriverReport> response = controller.Get();
            Assert.IsNotNull(response);            
        }
        [TestMethod]
        public void WhenRequestCallPost_ReturnsOKResponse()
        {
            Upload file = new Upload();
            file.file = "C:\\SafeAuto\\InputFile\\input.txt";
            bool response = controller.Post(file);
            Assert.IsTrue(response);
        }
    }
}
