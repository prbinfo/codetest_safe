
export default class UploadFile
{
    file:string="";

}