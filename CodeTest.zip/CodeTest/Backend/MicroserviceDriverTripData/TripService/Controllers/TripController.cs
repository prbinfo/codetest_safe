﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ExternalServices.DataAccess;
using Drivers.Model;
using Microsoft.Extensions.Logging;

namespace TripService.Controllers
{
    [ApiController]
    [Route("driver/report")]
    public class TripController : ControllerBase
    {
        public readonly IDriverReportService _driverReport;
        public readonly ILogger<TripController> _logger;

        public TripController(IDriverReportService driverReport, ILogger<TripController> logger)
        {
            this._driverReport = driverReport;
            _logger = logger;
        }

        /// <summary>
        /// uploads input file to /data
        /// </summary>
        /// <param name="inputFile"></param>
        /// <returns>true if file uploaded successfully</returns>
        /// <returns>false if the file is failed to upload</returns>

        [HttpPost]
        public bool Post([FromBody] Upload file)
        {
            return _driverReport.FileUpload(file.file);
        }

        /// <summary>
        /// Get the driver trip report
        /// </summary>
        /// <returns>trip report for each driver</returns>
        [HttpGet]
        public IEnumerable<DriverReport> Get()
        {
            return _driverReport.GetDriverReports();
        }

    }
}
