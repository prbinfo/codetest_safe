import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http'
import { stringify } from '@angular/compiler/src/util';

import { Observable } from 'rxjs';
import UploadFile from '../model/UploadFile';

@Injectable({
  providedIn: 'root'
})
export class DriverServiceService {   

  constructor(private httpClient: HttpClient) {

  }  
  invokeFileUploadPost(file): Observable<any> {
    const endpoint = 'https://localhost:44325/driver/report'; 
    let formdata = new UploadFile();
      formdata.file=file         
    return this.httpClient.post(endpoint, formdata)
  }

  getReport(): Observable<any> {
    const endpoint = 'https://localhost:44325/driver/report';
    return this.httpClient.get<any>(endpoint);
  }

}
