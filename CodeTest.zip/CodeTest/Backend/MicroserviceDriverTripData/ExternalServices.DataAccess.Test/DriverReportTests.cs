using ExternalServices.DataAccess;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Extensions.Configuration;
using Moq;
using System.Collections.Generic;
using Drivers.Model;
using Microsoft.Extensions.Logging;

namespace ExternalServices.DataAccess.UnitTests
{
    [TestClass()]
    public class DriverReportTests
    {
        private IDriverReportService _driverReportService;

        [TestInitialize]
        public void SetUp()
        {
            Mock<IConfigurationSection> mockSection = new Mock<IConfigurationSection>();
            mockSection.Setup(x => x.Value).Returns("input.txt");

            Mock<IConfiguration> mockConfig = new Mock<IConfiguration>();
            mockConfig.Setup(x => x.GetSection(It.Is<string>(k => k == "DataFile"))).Returns(mockSection.Object);
            var mock = new Mock<ILogger<DriverReportService>>();
            ILogger<DriverReportService> logger = mock.Object;
            _driverReportService = new DriverReportService(mockConfig.Object, logger);
        }
        [TestMethod()]
        public void FileCreateTest()
        {
            string file = "C:\\SafeAuto\\input.txt";

            bool result = _driverReportService.FileUpload(file);
            Assert.IsTrue(result);
        }
        [TestMethod()]
        public void FileNotExistsTest()
        {
            string file = "C:\\SafeAuto\\input9.txt";
            bool result = _driverReportService.FileUpload(file);
            Assert.IsFalse(result);
        }
        [TestMethod()]
        public void GetDriverReportTest_FileExists()
        {
            List<DriverReport> drvrReports = new List<DriverReport>();
            drvrReports = (List<DriverReport>)_driverReportService.GetDriverReports();
            Assert.IsNotNull(drvrReports);
            Assert.AreEqual(drvrReports.Count, 2);
        }        
    }
}
