import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule} from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { DriverServiceService } from './services/driver-service.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
   declarations: [
      
      AppComponent,
     
   ],
   imports: [
      BrowserModule,
      
      ReactiveFormsModule,
      HttpClientModule,
   
     
   ],
   providers: [DriverServiceService],
  
   bootstrap: [AppComponent]
})
export class AppModule { }